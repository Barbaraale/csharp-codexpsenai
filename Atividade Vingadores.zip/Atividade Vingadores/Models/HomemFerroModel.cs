namespace Atividade_Vingadores.Models
{
    public class HomemFerroModel : BaseModel
    {
        public bool Armadura { get; set; }

        public string Cor { get; set; }
    }
}