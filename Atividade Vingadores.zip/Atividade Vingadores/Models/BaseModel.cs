namespace Atividade_Vingadores.Models
{
    public class BaseModel
    {
        public string Equipe { get; set; }
        
        public string Vida { get; set; }

        
    }
}