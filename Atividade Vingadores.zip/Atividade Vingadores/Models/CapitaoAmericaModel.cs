using System;

namespace Atividade_Vingadores.Models
{
    public class CapitaoAmericaModel : BaseModel
    {
        public bool Escudo { get; set; }

        public string Cor { get; set; }

    }
}